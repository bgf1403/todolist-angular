// Importando estilos
import "./style.css";
import "material-icons/iconfont/material-icons.css";
import { ListaDeTarefas } from "./models/ListaDeTarefas";

const lt:ListaDeTarefas = new ListaDeTarefas(document.querySelector("main"));